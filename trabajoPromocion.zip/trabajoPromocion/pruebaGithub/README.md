# wordix
Juego Wordix desarrollado en Introducción a la Programación (FAI)

# Materia 2023

    Introducción a la Programación
    Tecnicatura en Desarrollo Web
    Facultad de Informática
    Universidad Nacional Del Comahue

    # Integrantes del Grupo N°11

    ** Facundo Nehuen Ledesma - Legajo 4238 - email: faculedesmabertalot@gmail.com - Github: facuLedesmaBertalot
    ** Maitena Durand- Legajo 5098- email: maitenadurand@gmail.com- Github: maitenadurand
