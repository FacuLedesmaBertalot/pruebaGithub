<?php
echo "Hola mundo.";
echo "soy yo";
?>